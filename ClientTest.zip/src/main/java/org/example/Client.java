package org.example;

import edu.augusta.sccs.trivia.Question;
import edu.augusta.sccs.trivia.QuestionsReply;
import edu.augusta.sccs.trivia.QuestionsRequest;
import edu.augusta.sccs.trivia.TriviaQuestionsGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import edu.augusta.sccs.trivia.*;


import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;



//System.err, printLn

public class Client {
    private static final Logger logger = Logger.getLogger(Client.class.getName());
    private final TriviaQuestionsGrpc.TriviaQuestionsBlockingStub blockingStub;
    private final ManagedChannel channel;
    private final List<OfflineAnswer> pendingAnswers = new ArrayList<>();
    private String playerUuid;
    private String playerUsername;

    public Client(String host, int port) {
        this(ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext()
                .build());
    }

    Client(ManagedChannel channel) {
        this.channel = channel;
        blockingStub = TriviaQuestionsGrpc.newBlockingStub(channel);
    }

    private void registerPlayer(String username) {
        logger.info("Registering player: " + username);
        try {
            // Create new player
            Player player = Player.newBuilder()
                    .setUsername(username)
                    .setLastDifficulty(1) // Default difficulty
                    .build();

            PlayerRegistrationRequest request = PlayerRegistrationRequest.newBuilder()
                    .setPlayer(player)
                    .build();

            PlayerReply reply = blockingStub.registerPlayer(request);

            // Store player info for later use
            this.playerUuid = reply.getPlayer().getUuid();
            this.playerUsername = reply.getPlayer().getUsername();

            logger.info("Successfully registered player. UUID: " + playerUuid);

        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed: " + e.getStatus());
            throw e;
        }
    }

    private List<Question> fetchQuestions(int difficulty, int count) {
        logger.info("Fetching " + count + " questions with difficulty: " + difficulty);
        try {
            QuestionsRequest request = QuestionsRequest.newBuilder()
                    .setDifficulty(difficulty)
                    .setNumberOfQuestions(count)
                    .build();

            QuestionsReply reply = blockingStub.getQuestions(request);
            List<Question> questions = reply.getQuestionsList();
            logger.info("Received " + questions.size() + " questions");
            return questions;

        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed: " + e.getStatus());
            throw e;
        }
    }
    //This method works, we just used the batch submission in our test
    private boolean submitAnswer(String questionUuid, String answer) {
        logger.info("Submitting answer for question: " + questionUuid);
        try {
            AnswerRequest request = AnswerRequest.newBuilder()
                    .setPlayerUuid(playerUuid)
                    .setQuestionUuid(questionUuid)
                    .setAnswer(answer)
                    .build();

            AnswerReply reply = blockingStub.submitAnswer(request);
            boolean isCorrect = reply.getCorrect();
            logger.info("Answer was " + (isCorrect ? "correct" : "incorrect"));
            return isCorrect;

        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed: " + e.getStatus());
            throw e;
        }
    }


    public void queueAnswer(String questionUuid, String answer, boolean isCorrect) {
        OfflineAnswer offlineAnswer = OfflineAnswer.newBuilder()
                .setQuestionUuid(questionUuid)
                .setAnswer(answer)
                .setTimestampMillis(Instant.now().toEpochMilli())
                .build();

        synchronized(pendingAnswers) {
            pendingAnswers.add(offlineAnswer);
        }

        // If we have enough answers, try to submit the batch
        if (pendingAnswers.size() >= 10) { // Arbitrary batch size threshold
            submitPendingAnswers();
        }
    }

    //attempts to submit all answers to the pending server
    public boolean submitPendingAnswers() {
        if (pendingAnswers.isEmpty()) {
            return true;
        }

        List<OfflineAnswer> answersToSubmit;
        synchronized(pendingAnswers) {
            answersToSubmit = new ArrayList<>(pendingAnswers);
            pendingAnswers.clear();
        }

        try {
            BatchAnswerRequest request = BatchAnswerRequest.newBuilder()
                    .setPlayerUuid(playerUuid)
                    .addAllAnswers(answersToSubmit)
                    .build();

            logger.info("Submitting batch of " + answersToSubmit.size() + " answers");

            BatchAnswerReply reply = blockingStub.submitBatchAnswers(request);

            if (reply.getSuccess()) {
                logger.info("Successfully submitted batch answers");
                return true;
            } else {
                logger.warning("Failed to submit batch answers: " + reply.getErrorMessage());
                // Re-queue failed answers
                synchronized(pendingAnswers) {
                    pendingAnswers.addAll(0, answersToSubmit);
                }
                return false;
            }

        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed: " + e.getStatus());
            // Re-queue failed answers
            synchronized(pendingAnswers) {
                pendingAnswers.addAll(0, answersToSubmit);
            }
            return false;
        }
    }

    private int getPlayerDifficulty() {
        logger.info("Retrieving player difficulty level for UUID: " + playerUuid);
        try {
            PlayerRequest request = PlayerRequest.newBuilder()
                    .setUuid(playerUuid)
                    .build();

            PlayerReply reply = blockingStub.getPlayer(request);
            int difficulty = reply.getPlayer().getLastDifficulty();
            logger.info("Current difficulty level: " + difficulty);
            return difficulty;

        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed: " + e.getStatus());
            throw e;
        }
    }


    public void runTestSequence() {
        try {

             {
                try {
                    String testUsername = "TestPlayer_" + UUID.randomUUID().toString().substring(0, 8);
                    logger.info("Registerin a test player with username: " + testUsername);
                    registerPlayer(testUsername);

                    // Test fetching questions
                    int difficulty = 2;
                    int count = 5;
                    List<Question> questions = fetchQuestions(difficulty, count);

                    if (questions.isEmpty()) {
                        logger.warning("No questions retrieved from the server.");
                    } else {
                        for (Question question : questions) {
                            logger.info("Question: " + question.getQuestion());
                            logger.info("Answer: " + question.getAnswer());
                        }
                    }
                } catch (Exception e) {
                    logger.severe("Test sequence failed: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            // Test 7: Inserts 35 questions and demonstrates the "Daemon" can update independent of the direct update call
            logger.info("Starting Test 7");
                // Fetch 35 questions of difficulty level 3
                int difficulty = 3; // Difficulty level for testing
                int questionCount = 35; // Number of questions to fetch
                List<Question> questions = fetchQuestions(difficulty, questionCount);

                if (questions.isEmpty()) {
                    logger.warning("No questions were retrieved. Test 7 cannot proceed.");
                    return;
                }

                // Submiting answers for all retrieved questions
                for (int i = 0; i < questions.size(); i++) {
                    Question question = questions.get(i);

                    // Alternate between correct and incorrect answers
                    String simulatedAnswer = (i % 2 == 0) ? question.getAnswer() : "Incorrect Answer";

                    // Submit the answer
                    boolean isCorrect = submitAnswer(question.getUuid(), simulatedAnswer);
                    logger.info("Submitted answer for question UUID: " + question.getUuid() + ". Correct: " + isCorrect);
                }

                // Wait for the daemon to process the updates
                logger.info("Waiting for the daemon to process updates...");
                Thread.sleep(300000); // Wait for 5 minutes

                // Fetch the updated player difficulty
                int updatedDifficulty = getPlayerDifficulty();
                logger.info("Updated player difficulty after daemon processing: " + updatedDifficulty);

            } catch (Exception e) {
                logger.severe("Test 7 failed: " + e.getMessage());
                e.printStackTrace();
            }

    }

    public static void main(String[] args) throws InterruptedException {
        Client client = new Client("localhost", 50051);

        try {
            client.runTestSequence();
        } finally {
            client.channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
        }
    }
}
